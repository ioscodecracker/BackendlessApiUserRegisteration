//
//  LoginDetails.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 10/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import UIKit

struct LoginModel:Encodable{
    let login:String
    let password:String
}
