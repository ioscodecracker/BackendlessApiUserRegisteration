//
//  UserRegistrationProtocol.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 11/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import UIKit


protocol UserRegistrationApiProtocol {
    func callingMockLoginAPI(loginModel:LoginModel, completionHandler:@escaping ([String:Any]?,Error?)->())
}
