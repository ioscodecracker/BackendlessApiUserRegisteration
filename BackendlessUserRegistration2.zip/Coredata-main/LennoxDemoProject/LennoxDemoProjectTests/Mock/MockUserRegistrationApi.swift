//
//  MockUserRegistrationApi.swift
//  LennoxDemoProjectTests
//
//  Created by Bargav Munusamy Sampath on 11/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import UIKit

@testable import LennoxDemoProject

class MockUserRegistrationApi{
    
    var shouldReturnError = false
    var loginWascalled = false
    
    enum MockServiceError: Error{
        case login
    }
    
    func reset(){
        shouldReturnError = false
        loginWascalled = false
    }
    
    convenience init(){
        self.init(false)
    }
    
    init(_ shouldReturnError:Bool){
        self.shouldReturnError = shouldReturnError
    }
    
    let mockLoginJSONResponse: [String:Any] = [
        "lastLogin" : 1610396619279,
        "userStatus" : "ENABLED",
        "mobileNumber" : "9012345678",
        "created" : 1610227277000,
        "ownerID" : "5C6C5358-FC12-476F-BCD0-6150D1564EE3",
        "socialAccount" : "BACKENDLESS",
        "phoneNumber" : "",
        "name" : "MSB",
        "responseModelClass" : "Users",
        "blUserLocale" : "en",
        "userToken" : "C217C2BA-35B6-4D68-83A6-B9BF13BDEC04",
        "updated" : "",
        "email" : "msb@gmail.com",
        "objectID" : "5C6C5358-FC12-476F-BCD0-6150D1564EE3"
    ]
}

extension MockUserRegistrationApi:UserRegistrationApiProtocol{
    
    func callingMockLoginAPI(loginModel: LoginModel, completionHandler: @escaping ([String : Any]?, Error?) -> ()) {
        
        loginWascalled = true
        
        if shouldReturnError{
            completionHandler(nil,MockServiceError.login)
        }
        else{
            completionHandler(mockLoginJSONResponse,nil)
        }
    }
}
