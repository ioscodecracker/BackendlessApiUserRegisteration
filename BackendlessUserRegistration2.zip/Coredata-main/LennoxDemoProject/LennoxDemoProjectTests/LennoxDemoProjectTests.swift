//
//  LennoxDemoProjectTests.swift
//  LennoxDemoProjectTests
//
//  Created by vijay g on 22/12/20.
//  Copyright © 2020 developer. All rights reserved.
//

import XCTest

@testable import LennoxDemoProject

class LennoxDemoProjectTests: XCTestCase {
    
    let mockUserRegistrationApi = MockUserRegistrationApi()
    
    override func setUp(){
    }
    
    func testLoginResponse(){
        
        let loginModel = LoginModel(login: "msb@gmail.com", password: "1234")
        
        //let expectation = self.expectation(description: "Login Response Parse Expectation")
        mockUserRegistrationApi.callingMockLoginAPI(loginModel: loginModel) { (json, error) in
            
            XCTAssertNil(error)
            guard let json = json else{
                XCTFail()
                return
            }
            do {
                let jsonData = try JSONSerialization.data(withJSONObject: json, options: [])
                let responseModel = try JSONDecoder().decode(ResponseModel.self, from: jsonData)
                let name = responseModel.name
                let email = responseModel.email
                let userToken = responseModel.userToken
                print(name,email,userToken)
                XCTAssertNotNil(name)
                XCTAssertNotNil(email)
                XCTAssertNotNil(jsonData)
                //expectation.fulfill()
            } catch {
                // XCTFail(error.localizedDescription)
            }
        }
        // self.waitForExpectations(timeout: 10.0, handler: nil)
    }
}


/*
 //TokenService.tokenInstance.saveToken(token: userToken)
 //                print(userToken)
 //
 //                let alertController = UIAlertController(title: "Login", message: "\(name) Login Success for email: \(email)", preferredStyle: .alert)
 //                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
 //                    let ratingPageVC = self.storyBoard.instantiateViewController(withIdentifier: "RatingPageViewController") as! RatingPageViewController
 //                    self.navigationController?.pushViewController(ratingPageVC, animated: true)
 // }))
 //self.present(alertController, animated: true, completion: nil)
 
 //                let alertController = UIAlertController(title: "Login", message: message, preferredStyle: .alert)
 //                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
 //                self.present(alertController, animated: true, completion: nil)
 //return
 */
