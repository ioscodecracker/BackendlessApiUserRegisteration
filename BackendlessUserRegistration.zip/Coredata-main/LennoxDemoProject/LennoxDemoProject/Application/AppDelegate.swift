//
//  AppDelegate.swift
//  LennoxDemoProject
//
//  Created by vijay g on 22/12/20.
//  Copyright © 2020 developer. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        IQKeyboardManager.shared.enable = true
        
        let vc:UIViewController?
        
        if TokenService.tokenInstance.checkForLogin(){
            print("Already loggedin - Rating Page")
            vc = RatingPageViewController.sharedInstance.showVC(identifier: "RatingPageViewController")
        } else{print("logout pressed and now signin screen")
            vc = LoginViewController.sharedInstance.showVC(identifier: "LoginViewController")
        }
        let navVC = UINavigationController(rootViewController: vc!)
        window?.rootViewController = navVC
        window?.makeKeyAndVisible()
        return true
    }
}

