//
//  BackendlessApiUrl.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 10/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import UIKit

let appId = "139920EA-AE6E-6AEB-FF6B-D676B902F700"
let restAPIKEY = "F657683F-3EE9-4E2F-AD8A-C59631AF98C5"
let baseURL = "https://api.backendless.com/\(appId)/\(restAPIKEY)/users"
let registerURL = "\(baseURL)/register"
let loginURL = "\(baseURL)/login"
let logoutURL = "\(baseURL)/logout"

struct TokenKey{
    static let userLogin = "USER_LOGIN_KEY"
}




/*
 POST method: login, signup
 GET method: logout
 
 //Networking call setup
 step1: https url
 step2: networkcall Alamofire
 step3: post method, loginModel parameter, headers
 step4: reponse.result - success, failure
 step5: success: jsondecoder, completionhandler(success(json decoded data as Any))
 step6: failure: completionhandler(failure(custom error message))
 //API call setup
 step7: api call passing loginDetails as paramter
 step8: receive jsondecoded data after successfull network call
 step9: cast it to required responseModel and retrieve values like name,email,etc
 step10: showAlerts for succes/failure
 */
