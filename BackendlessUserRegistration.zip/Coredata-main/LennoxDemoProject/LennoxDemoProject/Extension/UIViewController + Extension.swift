//
//  UIViewController + Extension.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 11/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import UIKit

extension RatingPageViewController{
        
        static let sharedInstance = RatingPageViewController()
        
        func showVC(identifier:String)->UIViewController{
            let vc = self.storyBoard.instantiateViewController(withIdentifier: identifier) as! RatingPageViewController
            return vc
        }
}

extension LoginViewController{
    
    static let sharedInstance = LoginViewController()
  
    func showVC(identifier:String)->UIViewController{
        let vc = self.storyBoard.instantiateViewController(withIdentifier: identifier) as! LoginViewController
        return vc
    }
}


