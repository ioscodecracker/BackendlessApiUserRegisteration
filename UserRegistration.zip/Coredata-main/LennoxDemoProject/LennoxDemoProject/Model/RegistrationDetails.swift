//
//  RegistrationDetails.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 10/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import UIKit

struct RegistrationDetails:Encodable{
    
    let name:String
    let email:String
    let mobileNumber:String
    let password:String
}

// MARK: - ResponseModel
struct ResponseModel: Codable {
    let lastLogin: Int
    let userStatus, mobileNumber: String
    let created: Int
    let ownerID, socialAccount: String
    //let phoneNumber: JSONNull?
    let name, responseModelClass, blUserLocale, userToken: String
    //let updated: JSONNull?
    let email, objectID: String

    enum CodingKeys: String, CodingKey {
        case lastLogin, userStatus, mobileNumber, created
        case ownerID = "ownerId"
        case socialAccount, name
        case responseModelClass = "___class"
        case blUserLocale
        case userToken = "user-token"
        case email
        case objectID = "objectId"
    }
}

