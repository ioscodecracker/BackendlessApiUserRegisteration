//
//  APIHandler.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 10/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation
import Alamofire

enum APIErrors: Error{
    case custom(message:String)
}

typealias Handler = (Swift.Result<Any?, APIErrors>)->Void

class APIHandler{
    
    static let sharedInstance = APIHandler()
    
    func detailsRegisterAPI(registerDetails:RegistrationDetails, completionHandler:@escaping (Bool,String)->()){
        let headers: HTTPHeaders = [.contentType("application/json")]
        
        AF.request(registerURL, method: .post, parameters: registerDetails, encoder: JSONParameterEncoder.default, headers: headers).response{
            response in
            debugPrint(response)
            switch response.result{
            case .success(let data):
                do{
                    if let jsonData = try JSONSerialization.jsonObject(with: data!, options: []) as? [String:Any] {
                        
                        if ((response.response?.statusCode)! == 200){ completionHandler(true,"User Registered Successfully")}
                        else{
                            if let message = jsonData["message"] as? String {
                            completionHandler(false,message)}
                        }
                    }
                }catch {print(error.localizedDescription)}
            case .failure(let err):
                print(err.localizedDescription)
            }            
        }
    }
    
    func callingLoginAPI(loginModel:LoginModel, completionHandler:@escaping Handler){
        let headers: HTTPHeaders = [.contentType("application/json")]
        
        AF.request(loginURL, method: .post, parameters: loginModel, encoder: JSONParameterEncoder.default, headers: headers).response{
            response in
            debugPrint(response)
            switch response.result{
            case .success(let data):
                do{
                    let jsonData = try JSONDecoder().decode(ResponseModel.self, from: data!)
                    if response.response?.statusCode == 200{ completionHandler(.success(jsonData))}
                    else{completionHandler(.failure(.custom(message: "Please check your network connectivity")))}
                }catch {print(error.localizedDescription)}
                completionHandler(.failure(.custom(message: "Please check your network connectivity")))
            case .failure(let err):
                print(err.localizedDescription)
                completionHandler(.failure(.custom(message: "Please try again")))
            }
        }
    }
}
