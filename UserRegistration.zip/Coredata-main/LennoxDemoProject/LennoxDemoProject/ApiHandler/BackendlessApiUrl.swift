//
//  BackendlessApiUrl.swift
//  LennoxDemoProject
//
//  Created by Bargav Munusamy Sampath on 10/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import Foundation

let appId = "139920EA-AE6E-6AEB-FF6B-D676B902F700"
let restAPIKEY = "F657683F-3EE9-4E2F-AD8A-C59631AF98C5"
let baseURL = "https://api.backendless.com/\(appId)/\(restAPIKEY)/users"
let registerURL = "\(baseURL)/register"
let loginURL = "\(baseURL)/login"
