//
//  LennoxDemoProjectUITests.swift
//  LennoxDemoProjectUITests
//
//  Created by Bargav on 07/01/21.
//  Copyright © 2021 developer. All rights reserved.
//

import XCTest


class LennoxDemoProjectUITests: XCTestCase {
    
    let app = XCUIApplication()
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        
        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    
    //testing emptyFields
    func test_1_EmptyFields(){
        
        // UI tests must launch the application that they test.
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
        XCTAssertTrue(app.buttons["Login"].exists)
        app.buttons["Login"].tap()
        XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
        
    }
    
  //testing valid email and password empty
    func test_2_ValidEmailAndEmptyPassword(){
        
        let validEmailId = "msb@gmail.com"

        let emailIdTextField = app.textFields["Email Id"]
        XCTAssertTrue(emailIdTextField.exists)
        emailIdTextField.tap()
        emailIdTextField.typeText(validEmailId)


        let passwordTextField = app.secureTextFields["Password"]
        XCTAssertTrue(passwordTextField.exists)
        XCTAssertTrue(app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
        app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
        XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
        app.toolbars["Toolbar"].buttons["Done"].tap()
    }
    
    //testing valid password and empty emailId
       func test_3_EmptyEmailAndValidPassword(){
        
          let emptyEmailId = ""
          app.textFields["Email Id"].clearAndEnterText(text: emptyEmailId)
        
           let password = "iosswift"

           let emailIdTextField = app.textFields["Email Id"]
           XCTAssertTrue(emailIdTextField.exists)
           emailIdTextField.tap()

           let passwordTextField = app.secureTextFields["Password"]
           XCTAssertTrue(passwordTextField.exists)
           passwordTextField.tap()
           passwordTextField.typeText(password)
           XCTAssertTrue(app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
           app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
           XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
           app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
           XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
           app.toolbars["Toolbar"].buttons["Done"].tap()
       }
    
    //testing unregistered credentials
    func test_4_Unregisteredcredentials(){
        
          let emptyPassword = ""
          app.secureTextFields["Password"].clearAndEnterText(text: emptyPassword)
          
          let validEmailId = "msb@gmail.com"
          let validPassword = "iosAutomation"
          
          let emailIdTextField = app.textFields["Email Id"]
          XCTAssertTrue(emailIdTextField.exists)
          emailIdTextField.tap()
          emailIdTextField.typeText(validEmailId)
          
          
          let passwordTextField = app.secureTextFields["Password"]
          XCTAssertTrue(passwordTextField.exists)
          passwordTextField.tap()
          passwordTextField.typeText(validPassword)
          XCTAssertTrue(app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
          app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
          XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
          app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
          XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
          app.toolbars["Toolbar"].buttons["Done"].tap()
      }
    
    //testing invalid emailid
       func test_5_InvalidEmailIdAndValidPassword(){
        
            let emptyEmailId = ""
            app.textFields["Email Id"].clearAndEnterText(text: emptyEmailId)
            let emptyPassword = ""
            app.secureTextFields["Password"].clearAndEnterText(text: emptyPassword)

             
             let inValidEmailId = "mmm.gmail.com"
             let validPassword = "iosswift"
             
             let emailIdTextField = app.textFields["Email Id"]
             XCTAssertTrue(emailIdTextField.exists)
             emailIdTextField.tap()
             emailIdTextField.typeText(inValidEmailId)
             
             
             let passwordTextField = app.secureTextFields["Password"]
             XCTAssertTrue(passwordTextField.exists)
             passwordTextField.tap()
             passwordTextField.typeText(validPassword)
             XCTAssertTrue(app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
             app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
             XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
             app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
             XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
             app.toolbars["Toolbar"].buttons["Done"].tap()
           
         }
    
    
    
    //testing registered credentials
    func test_6_RegisteredCredentials(){
        
        
        let validEmailId = "msb@gmail.com"
        let validPassword = "1234"
        
        app.textFields["Email Id"].clearAndEnterText(text: validEmailId)
        app.secureTextFields["Password"].clearAndEnterText(text: validPassword)
        
        XCTAssertTrue(app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.exists)
        app/*@START_MENU_TOKEN@*/.staticTexts["Login"]/*[[".buttons[\"Login\"].staticTexts[\"Login\"]",".staticTexts[\"Login\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        XCTAssertTrue(app.alerts["Login"].scrollViews.otherElements.buttons["OK"].exists)
        app.alerts["Login"].scrollViews.otherElements.buttons["OK"].tap()
        
        let homePage = app.navigationBars["Movie Rating Page"]
        
        expectation(for:NSPredicate(format:"exists == 1"), evaluatedWith:homePage,handler:nil)
        waitForExpectations(timeout: 5, handler: nil)
        
        XCTAssertTrue(homePage.exists)
        XCTAssertTrue(homePage.buttons["Log Out"].exists)
        homePage.buttons["Log Out"].tap()
        
        let loginPage = app.navigationBars["Lennox Technology"]
        
        expectation(for:NSPredicate(format:"exists == 1"), evaluatedWith:loginPage,handler:nil)
        waitForExpectations(timeout: 5, handler: nil)
        
        XCTAssertTrue(loginPage.exists)
        XCTAssertTrue(app.toolbars["Toolbar"].buttons["Done"].exists)
        app.toolbars["Toolbar"].buttons["Done"].tap()
        
        
    }
}

extension XCUIElement {
    /**
     Removes any current text in the field before typing in the new value
     - Parameter text: the text to enter into the field
     */
    func clearAndEnterText(text: String) {
        guard let stringValue = self.value as? String else {
            XCTFail("Tried to clear and enter text into a non string value")
            return
        }
        
        self.tap()
        
        let deleteString = String(repeating: XCUIKeyboardKey.delete.rawValue, count: stringValue.count)
        
        self.typeText(deleteString)
        self.typeText(text)
    }
}

